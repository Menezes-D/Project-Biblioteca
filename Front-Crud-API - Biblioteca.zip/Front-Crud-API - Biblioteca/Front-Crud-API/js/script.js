const livrosContainer = document.getElementById('livrosList');
const toggleThemeBtn = document.getElementById('toggleThemeBtn');

let livros = [];

// Carregar os livros do servidor
async function loadLivros() {
    try {
        const response = await fetch('http://localhost:8080/api/livros');
        livros = await response.json();
        renderLivros();
    } catch (error) {
        console.error('Erro ao carregar livros:', error);
    }
}

// Renderizar os livros na tela
function renderLivros() {
    livrosContainer.innerHTML = '';
    livros.forEach((livro) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${livro.titulo}</strong> - ${livro.autor} (${livro.anoPublicacao}) ` +
            `<button onclick="editLivro(${livro.id})">Editar</button> ` +
            `<button onclick="deleteLivro(${livro.id})">Deletar</button>`;
        livrosContainer.appendChild(li);
    });
}

// Adicionar um novo livro
async function addLivro() {
    const titulo = document.getElementById('tituloInput').value;
    const autor = document.getElementById('autorInput').value;
    const editora = document.getElementById('editoraInput').value;
    const anoPublicacao = document.getElementById('anoInput').value;

    if (titulo && autor && editora && anoPublicacao) {
        const novoLivro = { titulo, autor, editora, anoPublicacao};

        try {
            const response = await fetch('http://localhost:8080/api/livros/adicionarLivro', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(novoLivro),
            });

            if (response.ok) {
                loadLivros();
                clearForm();
            } else {
                console.error('Erro ao cadastrar livro:', await response.text());
            }
        } catch (error) {
            console.error('Erro ao cadastrar livro:', error);
        }
    } else {
        alert('Por favor, preencha todos os campos.');
    }
}

// Editar um livro existente
async function editLivro(id) {
    const livro = livros.find(l => l.id === id);
    document.getElementById('tituloInput').value = livro.titulo;
    document.getElementById('autorInput').value = livro.autor;
    document.getElementById('editoraInput').value = livro.editora;
    document.getElementById('anoInput').value = livro.anoPublicacao;

    const addButton = document.querySelector('.form-container button');
    addButton.textContent = 'Salvar Alterações';
    addButton.onclick = () => saveEdit(id);
}

// Salvar as alterações feitas em um Livro
async function saveEdit(id) {
    const titulo = document.getElementById('tituloInput').value;
    const autor = document.getElementById('autorInput').value;
    const editora = document.getElementById('editoraInput').value;
    const anoPublicacao = document.getElementById('anoInput').value;

    const livroAtualizado = { titulo, autor, editora, anoPublicacao};

    try {
        const response = await fetch(`http://localhost:8080/api/livros/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(livroAtualizado),
        });

        if (response.ok) {
            loadLivros();
            clearForm();
            const addButton = document.querySelector('.form-container button');
            addButton.textContent = 'Adicionar Livro';
            addButton.onclick = addLivro;
        } else {
            console.error('Erro ao editar livro:', await response.text());
        }
    } catch (error) {
        console.error('Erro ao editar livro:', error);
    }
}

// Deletar um livro
async function deleteLivro(id) {
    try {
        const response = await fetch(`http://localhost:8080/api/livros/deletarLivro/${id}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            loadLivros();
        } else {
            console.error('Erro ao deletar livro:', await response.text());
        }
    } catch (error) {
        console.error('Erro ao deletar livro:', error);
    }
}

// Limpar o formulário após adicionar ou editar um livro
function clearForm() {
    document.getElementById('tituloInput').value = '';
    document.getElementById('autorInput').value = '';
    document.getElementById('editoraInput').value = '';
    document.getElementById('anoInput').value = '';
}

// Alternar entre tema claro e escuro
toggleThemeBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
});

// Inicializar com os livros carregados
loadLivros();
